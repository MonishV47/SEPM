# CampusHire — Placement Portal with AI Resume Matcher

A student/recruiter placement portal with job listings, applications, role-aware authentication and explainable resume-to-job keyword matching. The matching score is advisory only.

## Stack
React + Vite, Node.js + Express, MongoDB + Mongoose, JWT, Docker.

## Run locally (Docker)
1. Install Docker Desktop.
2. From repository root run `docker compose up --build`.
3. Open http://localhost:5173 and API health at http://localhost:5000/api/health.

## Run without Docker
- Start MongoDB locally.
- `cd server`, copy `.env.example` to `.env`, set `JWT_SECRET` and `MONGO_URI`, run `npm install`, `npm start`.
- In a second terminal: `cd client`, run `npm install`, `npm run dev`.

## Usage
Register as Student to browse and apply. Register as Recruiter to create jobs. Use resume text in the application prompt. Recruiters can view applicant lists through `GET /api/jobs/:id/applicants` when authenticated and authorized.

## API overview
- POST `/api/auth/register`, POST `/api/auth/login`
- GET `/api/jobs`, GET `/api/jobs/:id`, POST `/api/jobs` (recruiter), DELETE `/api/jobs/:id` (close)
- POST `/api/applications`, GET `/api/applications/mine`, PATCH `/api/applications/:id/status`
- POST `/api/match` (authenticated standalone match)
- GET `/api/health`

## Security and limitations
Set a long random JWT secret; do not commit `.env`. This starter is a prototype: production needs stronger rate limiting, audit logging, upload scanning, data retention controls, access controls, security testing and validated fairness evaluation. Matching is keyword-based and not a hiring prediction.
